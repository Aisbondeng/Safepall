import React from 'react';
import { motion } from 'framer-motion';
import { Shield, Zap, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate, Link } from 'react-router-dom';

const Welcome = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-neutral-900 via-background to-neutral-900 text-foreground flex flex-col items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.7, ease: "easeOut" }}
        className="text-center max-w-lg"
      >
        <motion.div 
          className="mb-8"
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.5 }}
        >
          <img  alt="SafePal logo icon - Welcome Screen" class="h-24 w-24 mx-auto text-primary"  src="https://images.unsplash.com/photo-1638913972776-873fc7af3fdf" />
        </motion.div>
        
        <motion.h1 
          className="text-4xl md:text-5xl font-extrabold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-primary via-purple-400 to-pink-500"
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.5 }}
        >
          Selamat Datang di Dompet Kripto Aman
        </motion.h1>
        
        <motion.p 
          className="text-lg text-muted-foreground mb-10"
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.5 }}
        >
          Kelola aset digital Anda dengan percaya diri dan mudah.
        </motion.p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          <motion.div 
            className="p-6 bg-neutral-800/70 rounded-xl border border-neutral-700 shadow-xl"
            initial={{ x: -30, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.5 }}
          >
            <Shield className="h-10 w-10 text-primary mb-3" />
            <h2 className="text-xl font-semibold mb-1">Keamanan Terdepan</h2>
            <p className="text-sm text-muted-foreground">Aset Anda dilindungi dengan teknologi enkripsi canggih.</p>
          </motion.div>
          <motion.div 
            className="p-6 bg-neutral-800/70 rounded-xl border border-neutral-700 shadow-xl"
            initial={{ x: 30, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.6, duration: 0.5 }}
          >
            <Zap className="h-10 w-10 text-yellow-400 mb-3" />
            <h2 className="text-xl font-semibold mb-1">Transaksi Cepat</h2>
            <p className="text-sm text-muted-foreground">Kirim dan terima kripto dengan kecepatan kilat.</p>
          </motion.div>
        </div>

        <motion.div 
          className="space-y-4 md:space-y-0 md:space-x-4 flex flex-col md:flex-row justify-center"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.7, duration: 0.5 }}
        >
          <Button 
            size="lg" 
            className="w-full md:w-auto safepal-gradient-button text-primary-foreground font-bold text-base py-6 px-8"
            onClick={() => navigate('/register')}
          >
            Buat Akun Baru <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
          <Button 
            size="lg" 
            variant="outline" 
            className="w-full md:w-auto text-base py-6 px-8 border-primary/50 text-primary hover:bg-primary/10 hover:text-primary"
            onClick={() => navigate('/login')}
          >
            Masuk ke Akun
          </Button>
        </motion.div>
        
        <motion.p 
            className="mt-10 text-xs text-muted-foreground"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8, duration: 0.5 }}
        >
            Dengan melanjutkan, Anda menyetujui <Link to="#" className="underline hover:text-primary">Ketentuan Layanan</Link> dan <Link to="#" className="underline hover:text-primary">Kebijakan Privasi</Link> kami.
        </motion.p>
      </motion.div>
    </div>
  );
};

export default Welcome;