import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Settings, Repeat, ChevronDown, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import Navigation from '@/components/layout/Navigation';
import { useNavigate } from 'react-router-dom';
import { useWallet } from '@/contexts/WalletContext';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";

const Swap = () => {
  const navigate = useNavigate();
  const { balance } = useWallet();
  const [fromAmount, setFromAmount] = useState('');
  const [toAmount, setToAmount] = useState('');
  const [fromCurrency, setFromCurrency] = useState({ symbol: 'BTC', name: 'Bitcoin', icon: <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" className="h-6 w-6 text-orange-500 fill-current"><path d="M29.333 16c0-2.385-.794-4.632-2.207-6.455l-2.406-3.145-1.538.087c-2.06-.46-4.24-.704-6.515-.704s-4.455.244-6.515.704l-1.538-.087L6.207 9.545C4.794 11.368 4 13.615 4 16s.794 4.632 2.207 6.455l2.406 3.145 1.538-.087c2.06.46 4.24.704 6.515.704s4.455-.244 6.515-.704l1.538.087 2.406-3.145C28.539 20.632 29.333 18.385 29.333 16zM14.61 21.154v2.32c0 .238-.192.43-.43.43h-1.59c-.238 0-.43-.192-.43-.43v-2.32H10.4v-1.473h1.76v-1.486h-1.76v-1.473h1.76V15.2H10.4v-1.473h1.76v-2.32c0-.238.192-.43.43-.43h1.59c.238 0 .43.192.43.43v2.32h1.76v1.473h-1.76v1.486h1.76v1.473h-1.76v1.535h1.76v1.473h-1.76zm7.056-1.473H19.9v2.32c0 .238-.192.43-.43.43h-1.59c-.238 0-.43-.192-.43-.43v-2.32H15.7v-1.473h1.76v-4.64c0-.238.192-.43.43-.43h1.59c.238 0 .43.192.43.43v4.64h1.756v1.473z"></path></svg> });
  const [toCurrency, setToCurrency] = useState({ symbol: 'USDT', name: 'Tether', icon: <img  alt="USDT icon" class="h-6 w-6" src="https://images.unsplash.com/photo-1644376770280-111ccd322f31" /> });
  const [slippage, setSlippage] = useState("0.5"); // Default slippage 0.5%

  const BTC_PRICE_IN_USDT = 65000;

  const handleAmountChange = (value, type) => {
    const numValue = parseFloat(value);
    if (isNaN(numValue) && value !== "") return;

    if (type === 'from') {
      setFromAmount(value);
      if (value === "" || numValue === 0) setToAmount("");
      else setToAmount((numValue * BTC_PRICE_IN_USDT).toFixed(2));
    } else {
      setToAmount(value);
      if (value === "" || numValue === 0) setFromAmount("");
      else setFromAmount((numValue / BTC_PRICE_IN_USDT).toFixed(8));
    }
  };

  const handleSwapCurrencies = () => {
    const tempCurrency = fromCurrency;
    setFromCurrency(toCurrency);
    setToCurrency(tempCurrency);
    const tempAmount = fromAmount;
    setFromAmount(toAmount);
    setToAmount(tempAmount);
  };

  const estimatedReceived = parseFloat(toAmount) * (1 - parseFloat(slippage)/100);

  return (
    <div className="min-h-screen pb-24 bg-background text-foreground">
      <header className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Button 
              variant="ghost" 
              size="icon" 
              className="mr-2"
              onClick={() => navigate('/')}
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-xl font-semibold">Tukar</h1>
          </div>
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="ghost" size="icon">
                <Settings className="h-5 w-5 text-muted-foreground" />
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-neutral-800 border-neutral-700">
              <DialogHeader>
                <DialogTitle>Pengaturan Swap</DialogTitle>
                <DialogDescription>Sesuaikan toleransi slippage Anda.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="slippage" className="text-right col-span-1 text-sm">Slippage (%)</label>
                  <Input id="slippage" value={slippage} onChange={(e) => setSlippage(e.target.value)} className="col-span-3 bg-neutral-900 border-neutral-600" />
                </div>
                <div className="flex space-x-2 mt-2">
                  {["0.1", "0.5", "1.0"].map(val => (
                    <Button key={val} variant={slippage === val ? "secondary" : "outline"} className="text-xs h-8" onClick={() => setSlippage(val)}>{val}%</Button>
                  ))}
                </div>
              </div>
              <DialogFooter>
                <DialogClose asChild>
                  <Button type="button" className="safepal-gradient-button">Simpan</Button>
                </DialogClose>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
        <Tabs defaultValue="swap" className="mt-2">
          <TabsList className="grid w-full grid-cols-4 bg-neutral-800 mb-4 text-xs h-9">
            <TabsTrigger value="swap" className="data-[state=active]:bg-neutral-700 data-[state=active]:text-primary">Swap</TabsTrigger>
            <TabsTrigger value="bridge" className="data-[state=active]:bg-neutral-700 data-[state=active]:text-primary">Bridge</TabsTrigger>
            <TabsTrigger value="buy_sell" className="data-[state=active]:bg-neutral-700 data-[state=active]:text-primary" onClick={() => navigate('/buy')}>Beli/Jual</TabsTrigger>
            <TabsTrigger value="exchange" className="data-[state=active]:bg-neutral-700 data-[state=active]:text-primary">Exchange</TabsTrigger>
          </TabsList>
        </Tabs>
      </header>
      
      <main className="px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="space-y-3"
        >
          <Card className="bg-neutral-800 border-neutral-700 rounded-lg shadow-md">
            <CardHeader className="p-3 border-b border-neutral-700">
              <CardTitle className="text-sm font-medium text-muted-foreground">Bayar</CardTitle>
            </CardHeader>
            <CardContent className="p-3">
              <div className="flex items-center justify-between">
                <Input 
                  type="number" 
                  placeholder="0" 
                  value={fromAmount}
                  onChange={(e) => handleAmountChange(e.target.value, 'from')}
                  className="text-2xl font-semibold bg-transparent border-none focus:ring-0 p-0 h-auto w-full" 
                />
                <Button variant="ghost" className="p-2 h-auto bg-neutral-700 hover:bg-neutral-600">
                  <div className="flex items-center">
                    {fromCurrency.icon}
                    <span className="ml-2 text-sm font-medium">{fromCurrency.symbol}</span>
                    <ChevronDown className="h-4 w-4 ml-1 text-muted-foreground" />
                  </div>
                </Button>
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                Saldo: {balance.toFixed(5)} {fromCurrency.symbol}
                <Button variant="link" size="sm" className="text-primary h-auto p-0 ml-2 text-xs" onClick={() => handleAmountChange(balance.toString(), 'from')}>MAX</Button>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-center my-[-6px] z-10">
            <Button variant="secondary" size="icon" className="rounded-full bg-neutral-700 hover:bg-neutral-600 border-4 border-background h-8 w-8" onClick={handleSwapCurrencies}>
              <Repeat className="h-4 w-4 text-primary" />
            </Button>
          </div>

          <Card className="bg-neutral-800 border-neutral-700 rounded-lg shadow-md">
            <CardHeader className="p-3 border-b border-neutral-700">
              <CardTitle className="text-sm font-medium text-muted-foreground">Terima (Estimasi)</CardTitle>
            </CardHeader>
            <CardContent className="p-3">
              <div className="flex items-center justify-between">
                <Input 
                  type="number" 
                  placeholder="0" 
                  value={toAmount}
                  onChange={(e) => handleAmountChange(e.target.value, 'to')}
                  className="text-2xl font-semibold bg-transparent border-none focus:ring-0 p-0 h-auto w-full" 
                />
                <Button variant="ghost" className="p-2 h-auto bg-neutral-700 hover:bg-neutral-600">
                  <div className="flex items-center">
                    {toCurrency.icon}
                    <span className="ml-2 text-sm font-medium">{toCurrency.symbol}</span>
                    <ChevronDown className="h-4 w-4 ml-1 text-muted-foreground" />
                  </div>
                </Button>
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                Harga: 1 {fromCurrency.symbol} ≈ {BTC_PRICE_IN_USDT.toLocaleString()} {toCurrency.symbol}
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-neutral-800 border-neutral-700 rounded-lg shadow-md p-3 text-xs">
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Toleransi Slippage</span>
              <span className="text-primary">{slippage}%</span>
            </div>
            {toAmount && parseFloat(toAmount) > 0 && (
              <div className="flex justify-between items-center mt-1">
                <span className="text-muted-foreground">Minimum Diterima</span>
                <span>{estimatedReceived > 0 ? estimatedReceived.toFixed(toCurrency.symbol === 'BTC' ? 8 : 2) : '0.00'} {toCurrency.symbol}</span>
              </div>
            )}
            <div className="flex justify-between items-center mt-1">
              <span className="text-muted-foreground">Biaya Jaringan</span>
              <span>≈ $0.50</span>
            </div>
          </Card>

          <Button 
            className="w-full safepal-gradient-button text-primary-foreground font-semibold py-3 h-auto text-base mt-4" 
            disabled={!fromAmount || parseFloat(fromAmount) <= 0 || parseFloat(fromAmount) > balance || !toAmount || parseFloat(toAmount) <=0 }
          >
            Tukar Sekarang
          </Button>
        </motion.div>
      </main>
      
      <Navigation />
    </div>
  );
};

export default Swap;