import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Filter, CalendarDays, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import Navigation from '@/components/layout/Navigation';
import TransactionItem from '@/components/wallet/TransactionItem';
import { useWallet } from '@/contexts/WalletContext';
import { useNavigate } from 'react-router-dom';

const History = () => {
  const navigate = useNavigate();
  const { transactions } = useWallet();
  const [filter, setFilter] = useState('all');
  
  const filteredTransactions = filter === 'all' 
    ? transactions 
    : transactions.filter(t => t.type === filter);
  
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  
  return (
    <div className="min-h-screen pb-24 bg-background text-foreground">
      <header className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Button 
              variant="ghost" 
              size="icon" 
              className="mr-2"
              onClick={() => navigate('/')}
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-xl font-semibold">Riwayat Transaksi</h1>
          </div>
          <div className="flex items-center space-x-1">
            <Button variant="ghost" size="icon">
              <CalendarDays className="h-5 w-5 text-muted-foreground" />
            </Button>
            <Button variant="ghost" size="icon">
              <Filter className="h-5 w-5 text-muted-foreground" />
            </Button>
            <Button variant="ghost" size="icon">
              <Download className="h-5 w-5 text-muted-foreground" />
            </Button>
          </div>
        </div>
      </header>
      
      <main className="px-4">
        <Tabs defaultValue="all" className="mt-2" onValueChange={setFilter}>
          <TabsList className="grid w-full grid-cols-3 mb-4 bg-neutral-800">
            <TabsTrigger value="all" className="data-[state=active]:bg-neutral-700 data-[state=active]:text-primary">Semua</TabsTrigger>
            <TabsTrigger value="send" className="data-[state=active]:bg-neutral-700 data-[state=active]:text-primary">Terkirim</TabsTrigger>
            <TabsTrigger value="receive" className="data-[state=active]:bg-neutral-700 data-[state=active]:text-primary">Diterima</TabsTrigger>
          </TabsList>
          
          <motion.div
            variants={container}
            initial="hidden"
            animate="show"
            className="space-y-2"
          >
            {filteredTransactions.length > 0 ? (
              filteredTransactions.map(transaction => (
                <TransactionItem key={transaction.id} transaction={transaction} />
              ))
            ) : (
              <Card className="bg-neutral-800 border-neutral-700 rounded-lg">
                <CardContent className="p-10 text-center">
                  <p className="text-muted-foreground">Tidak ada transaksi ditemukan.</p>
                </CardContent>
              </Card>
            )}
          </motion.div>
        </Tabs>
      </main>
      
      <Navigation />
    </div>
  );
};

export default History;