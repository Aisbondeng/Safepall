import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Edit3, PlusCircle, Trash2, Check, Copy } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useWallet } from '@/contexts/WalletContext';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogTrigger,
  DialogClose
} from "@/components/ui/dialog";


const WalletManagement = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { walletName, updateWalletName, address } = useWallet();
  const [editingName, setEditingName] = useState(false);
  const [newName, setNewName] = useState(walletName);
  const [copied, setCopied] = useState(false);

  const handleSaveName = () => {
    updateWalletName(newName);
    setEditingName(false);
  };

  const copyAddress = () => {
    navigator.clipboard.writeText(address);
    setCopied(true);
    toast({
      title: "Alamat Disalin",
      description: "Alamat wallet berhasil disalin.",
      className: "bg-neutral-800 text-foreground border-neutral-700"
    });
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen pb-16 bg-background text-foreground">
      <header className="p-4 sticky top-0 bg-background z-10 border-b border-neutral-700">
        <div className="flex items-center">
          <Button 
            variant="ghost" 
            size="icon" 
            className="mr-2"
            onClick={() => navigate('/')}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-semibold">Manajemen Wallet</h1>
        </div>
      </header>

      <main className="px-4 py-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="space-y-4"
        >
          <Card className="bg-neutral-800 border-neutral-700 rounded-lg">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-base">Nama Wallet Saat Ini</CardTitle>
              {!editingName && (
                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => { setEditingName(true); setNewName(walletName); }}>
                  <Edit3 className="h-4 w-4 text-primary" />
                </Button>
              )}
            </CardHeader>
            <CardContent>
              {editingName ? (
                <div className="flex items-center space-x-2">
                  <Input 
                    value={newName} 
                    onChange={(e) => setNewName(e.target.value)} 
                    className="bg-neutral-900 border-neutral-600 h-9"
                  />
                  <Button size="icon" className="h-9 w-9 safepal-gradient-button" onClick={handleSaveName}>
                    <Check className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <p className="text-lg font-semibold">{walletName}</p>
              )}
            </CardContent>
          </Card>

          <Card className="bg-neutral-800 border-neutral-700 rounded-lg">
            <CardHeader>
              <CardTitle className="text-base">Alamat Wallet</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between bg-neutral-900 p-2 rounded-md">
                <p className="text-xs font-mono text-muted-foreground truncate mr-2">{address}</p>
                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={copyAddress}>
                  {copied ? <Check className="h-4 w-4 text-green-400" /> : <Copy className="h-4 w-4 text-primary" />}
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-neutral-800 border-neutral-700 rounded-lg">
            <CardHeader>
              <CardTitle className="text-base">Tindakan Wallet</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button variant="outline" className="w-full justify-start bg-neutral-700/30 hover:bg-neutral-700 border-neutral-600">
                <PlusCircle className="h-4 w-4 mr-2 text-green-400" /> Buat Wallet Baru
              </Button>
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="destructive" className="w-full justify-start bg-red-500/10 hover:bg-red-500/20 border-red-500/30 text-red-400">
                    <Trash2 className="h-4 w-4 mr-2" /> Hapus Wallet Ini
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-neutral-800 border-neutral-700">
                  <DialogHeader>
                    <DialogTitle>Hapus Wallet?</DialogTitle>
                    <DialogDescription>
                      Apakah Anda yakin ingin menghapus wallet "{walletName}"? Tindakan ini tidak dapat diurungkan dan semua data terkait akan hilang. Pastikan Anda telah mencadangkan private key Anda.
                    </DialogDescription>
                  </DialogHeader>
                  <DialogFooter>
                    <DialogClose asChild><Button variant="outline">Batal</Button></DialogClose>
                    <Button variant="destructive" onClick={() => toast({title: "Fitur Belum Tersedia", description:"Penghapusan wallet akan diimplementasikan."})}>Ya, Hapus</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardContent>
          </Card>

        </motion.div>
      </main>
    </div>
  );
};

export default WalletManagement;