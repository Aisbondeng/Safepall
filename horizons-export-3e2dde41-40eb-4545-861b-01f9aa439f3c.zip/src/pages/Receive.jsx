import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Copy, Check, Share2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import Navigation from '@/components/layout/Navigation';
import QRCode from '@/components/wallet/QRCode';
import { useWallet } from '@/contexts/WalletContext';
import { useNavigate } from 'react-router-dom';

const Receive = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { address } = useWallet();
  const [copied, setCopied] = useState(false);
  
  const copyToClipboard = () => {
    navigator.clipboard.writeText(address);
    setCopied(true);
    toast({
      title: "Alamat disalin",
      description: "Alamat Bitcoin berhasil disalin.",
      className: "bg-neutral-800 text-foreground border-neutral-700"
    });
    
    setTimeout(() => {
      setCopied(false);
    }, 2000);
  };
  
  const shareAddress = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Alamat Bitcoin Saya',
        text: `Ini alamat Bitcoin saya: ${address}`,
      })
      .catch((error) => {
         toast({
            variant: "destructive",
            title: "Gagal berbagi",
            description: "Tidak dapat berbagi alamat saat ini.",
            className: "bg-neutral-800 text-foreground border-neutral-700"
          })
      });
    } else {
      copyToClipboard(); // Fallback for browsers that don't support navigator.share
    }
  };
  
  return (
    <div className="min-h-screen pb-24 bg-background text-foreground">
      <header className="p-4">
        <div className="flex items-center">
          <Button 
            variant="ghost" 
            size="icon" 
            className="mr-2"
            onClick={() => navigate('/')}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-semibold">Terima BTC</h1>
        </div>
      </header>
      
      <main className="px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col items-center"
        >
          <Card className="bg-neutral-800 border-neutral-700 rounded-lg shadow-md w-full max-w-md">
            <CardContent className="p-6 flex flex-col items-center">
              <div className="mb-6 mt-2">
                <QRCode address={address} size={180} />
              </div>
              
              <div className="w-full space-y-3">
                <div className="space-y-1">
                  <Label htmlFor="address" className="text-xs text-muted-foreground">Alamat Bitcoin Anda</Label>
                  <div className="relative">
                    <Input
                      id="address"
                      value={address}
                      readOnly
                      className="bg-neutral-900 border-neutral-700 pr-10 font-mono text-xs h-12"
                    />
                    <Button
                      variant="ghost"
                      size="icon"
                      className="absolute right-1 top-1/2 transform -translate-y-1/2 h-10 w-10"
                      onClick={copyToClipboard}
                    >
                      {copied ? (
                        <Check className="h-5 w-5 text-green-400" />
                      ) : (
                        <Copy className="h-5 w-5 text-muted-foreground" />
                      )}
                    </Button>
                  </div>
                </div>
                
                <div className="flex space-x-3">
                  <Button 
                    className="flex-1 safepal-gradient-button text-primary-foreground font-semibold"
                    onClick={copyToClipboard}
                  >
                    <Copy className="h-4 w-4 mr-2" />
                    Salin
                  </Button>
                  <Button 
                    className="flex-1 bg-neutral-700 hover:bg-neutral-600 text-primary-foreground"
                    variant="secondary"
                    onClick={shareAddress}
                  >
                    <Share2 className="h-4 w-4 mr-2" />
                    Bagikan
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <div className="mt-6 text-center text-muted-foreground text-xs max-w-xs">
            <p>Pindai kode QR atau salin alamat di atas untuk menerima Bitcoin. Pastikan alamat sudah benar.</p>
          </div>
        </motion.div>
      </main>
      
      <Navigation />
    </div>
  );
};

export default Receive;