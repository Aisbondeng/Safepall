import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Search, Gift, Menu, Zap, Gamepad2, FileImage as ImageIcon, BarChart3, Link as LinkIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import Navigation from '@/components/layout/Navigation';
import { useNavigate, useLocation } from 'react-router-dom';
import { useWallet } from '@/contexts/WalletContext';

const dAppCategories = [
  { name: "DeFi", icon: BarChart3, color: "text-green-400", category: "defi" },
  { name: "Games", icon: Gamepad2, color: "text-blue-400", category: "games" },
  { name: "NFT", icon: ImageIcon, color: "text-purple-400", category: "nft" },
  { name: "Tools", icon: LinkIcon, color: "text-yellow-400", category: "tools" },
];

const popularDapps = [
  { name: "PancakeSwap", description: "Decentralized exchange", icon: <img  alt="PancakeSwap logo" src="https://images.unsplash.com/photo-1700821532755-35ef6e936621" />, category: "defi", url: "https://pancakeswap.finance/" },
  { name: "OpenSea", description: "NFT Marketplace", icon: <img  alt="OpenSea logo" src="https://images.unsplash.com/photo-1644143379190-08a5f055de1d" />, category: "nft", url: "https://opensea.io/" },
  { name: "Axie Infinity", description: "Play-to-earn game", icon: <img  alt="Axie Infinity logo" src="https://images.unsplash.com/photo-1641932269834-af141d2c2017" />, category: "games", url: "https://axieinfinity.com/" },
  { name: "Uniswap", description: "Decentralized trading protocol", icon: <img  alt="Uniswap logo" src="https://images.unsplash.com/photo-1642364706752-3af64cc1af5e" />, category: "defi", url: "https://uniswap.org/" },
];

const Dapps = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { walletName } = useWallet();
  const [searchTerm, setSearchTerm] = useState("");

  const queryParams = new URLSearchParams(location.search);
  const initialCategory = queryParams.get('category') || 'all';
  const [activeCategory, setActiveCategory] = useState(initialCategory);

  const filteredDapps = popularDapps.filter(dapp => 
    (activeCategory === 'all' || dapp.category === activeCategory) &&
    (dapp.name.toLowerCase().includes(searchTerm.toLowerCase()) || dapp.description.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="min-h-screen pb-24 bg-background text-foreground">
      <header className="p-4 sticky top-0 bg-background z-10 border-b border-neutral-700">
        <div className="flex items-center justify-between">
          <Button 
            variant="ghost" 
            size="icon" 
            className="mr-2"
            onClick={() => navigate('/')}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="flex-1 mx-2">
            <h1 className="text-xl font-semibold text-center">{walletName}</h1>
          </div>
          <Button variant="ghost" size="icon">
            <Gift className="h-5 w-5 text-muted-foreground" />
          </Button>
        </div>
        <div className="mt-3 relative">
          <Input 
            type="text" 
            placeholder="Cari DApp atau masukkan tautan" 
            className="bg-neutral-800 border-neutral-700 pl-10 h-11"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        </div>
      </header>
      
      <main className="px-4 py-4">
        <Card className="mb-4 bg-neutral-800 border-neutral-700 rounded-lg">
          <CardContent className="p-3">
            <img  alt="DApp promotion banner" className="w-full h-24 object-cover rounded-md" src="https://images.unsplash.com/photo-1651043701629-72e52595c479" />
          </CardContent>
        </Card>

        <div className="flex space-x-3 overflow-x-auto pb-3 mb-4 scrollbar-hide">
          <Button 
            variant={activeCategory === 'all' ? "secondary" : "outline"}
            className={`whitespace-nowrap px-4 h-10 rounded-lg ${activeCategory === 'all' ? 'bg-neutral-700 text-primary border-neutral-700' : 'bg-neutral-800 border-neutral-700 hover:bg-neutral-700 text-muted-foreground'}`}
            onClick={() => setActiveCategory('all')}
          >
            Semua
          </Button>
          {dAppCategories.map(cat => (
            <Button 
              key={cat.name} 
              variant={activeCategory === cat.category ? "secondary" : "outline"}
              className={`whitespace-nowrap px-4 h-10 rounded-lg flex items-center ${activeCategory === cat.category ? 'bg-neutral-700 text-primary border-neutral-700' : 'bg-neutral-800 border-neutral-700 hover:bg-neutral-700 text-muted-foreground'}`}
              onClick={() => setActiveCategory(cat.category)}
            >
              <cat.icon className={`h-4 w-4 mr-2 ${cat.color}`} />
              {cat.name}
            </Button>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="grid grid-cols-1 md:grid-cols-2 gap-3"
        >
          {filteredDapps.length > 0 ? filteredDapps.map(dapp => (
            <Card key={dapp.name} className="bg-neutral-800 border-neutral-700 rounded-lg hover:bg-neutral-700/50 transition-colors">
              <a href={dapp.url} target="_blank" rel="noopener noreferrer">
                <CardContent className="p-3 flex items-center">
                  <div className="w-10 h-10 rounded-md bg-neutral-700 flex items-center justify-center mr-3 overflow-hidden">
                    {dapp.icon}
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold">{dapp.name}</h3>
                    <p className="text-xs text-muted-foreground">{dapp.description}</p>
                  </div>
                </CardContent>
              </a>
            </Card>
          )) : (
            <div className="col-span-full text-center py-10">
              <CompassIcon className="h-16 w-16 text-neutral-600 mb-4 mx-auto" />
              <p className="text-muted-foreground">Tidak ada DApp yang cocok ditemukan.</p>
            </div>
          )}
        </motion.div>
      </main>
      
      <Navigation />
    </div>
  );
};


const CompassIcon = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <circle cx="12" cy="12" r="10" />
    <polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76" />
    <circle cx="12" cy="12" r="3" />
  </svg>
);

export default Dapps;