import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Mail, Lock, LogIn as LogInIcon, Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useWallet } from '@/contexts/WalletContext';
import { useNavigate, Link } from 'react-router-dom';

const Login = () => {
  const navigate = useNavigate();
  const { loginUser, loading } = useWallet();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      await loginUser(email, password);
      navigate('/');
    } catch (err) {
      setError("Email atau password salah. Silakan coba lagi.");
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <div className="absolute top-4 left-4">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => navigate('/welcome')}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </div>
        
        <div className="text-center mb-8">
          <img  alt="SafePal logo icon" class="h-16 w-16 mx-auto mb-4 text-primary" src="https://images.unsplash.com/photo-1642403711604-3908e90960ce" />
          <h1 className="text-3xl font-bold text-primary">Masuk</h1>
          <p className="text-muted-foreground">Akses dompet aman Anda.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="email"
                type="email"
                placeholder="anda@contoh.com"
                className="pl-10 bg-neutral-800 border-neutral-700 focus:border-primary"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="password"
                type={showPassword ? "text" : "password"}
                placeholder="Password Anda"
                className="pl-10 pr-10 bg-neutral-800 border-neutral-700 focus:border-primary"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="absolute right-2 top-1/2 transform -translate-y-1/2 h-7 w-7"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </Button>
            </div>
          </div>
          
          {error && <p className="text-sm text-destructive">{error}</p>}

          <Button 
            type="submit" 
            className="w-full safepal-gradient-button text-primary-foreground font-semibold py-3 text-base"
            disabled={loading}
          >
            {loading ? 'Memproses...' : <><LogInIcon className="mr-2 h-5 w-5" /> Masuk</>}
          </Button>
        </form>

        <p className="mt-8 text-center text-sm text-muted-foreground">
          Belum punya akun?{' '}
          <Link to="/register" className="font-semibold text-primary hover:underline">
            Daftar di sini
          </Link>
        </p>
         <p className="mt-2 text-center text-sm text-muted-foreground">
          Lupa password?{' '}
          <Link to="#" className="font-semibold text-primary hover:underline">
            Reset Password
          </Link>
        </p>
      </motion.div>
    </div>
  );
};

export default Login;