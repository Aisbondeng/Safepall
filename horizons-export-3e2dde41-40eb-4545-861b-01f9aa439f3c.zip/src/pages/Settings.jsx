import React from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, ChevronRight, Shield, BookKey, Settings as SettingsIcon, Network, Trash2, Palette, Languages, TrendingUp, LifeBuoy, Users, FileText, Sun, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import Navigation from '@/components/layout/Navigation';
import { useNavigate } from 'react-router-dom';
import { useWallet } from '@/contexts/WalletContext';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogTrigger,
  DialogClose
} from "@/components/ui/dialog";

const SettingSection = ({ title, children }) => (
  <div className="mb-4">
    {title && <h2 className="text-xs text-muted-foreground px-4 pb-1 pt-2 uppercase font-semibold">{title}</h2>}
    <Card className="bg-neutral-800 border-neutral-700 rounded-lg shadow-md overflow-hidden">
      <CardContent className="p-0 divide-y divide-neutral-700">
        {children}
      </CardContent>
    </Card>
  </div>
);

const SettingItem = ({ icon: Icon, title, value, onClick, destructive = false }) => {
  return (
    <motion.div
      whileTap={{ backgroundColor: destructive ? "hsl(var(--destructive)/0.2)" : "hsl(var(--accent))" }}
      className={`flex items-center justify-between p-3 cursor-pointer hover:bg-neutral-700/50 transition-colors ${destructive ? 'text-destructive hover:text-red-400' : ''}`}
      onClick={onClick}
    >
      <div className="flex items-center">
        {Icon && <Icon className={`h-5 w-5 mr-3 ${destructive ? '' : 'text-muted-foreground'}`} />}
        <span className="text-sm">{title}</span>
      </div>
      <div className="flex items-center">
        {value && <span className="text-sm text-muted-foreground mr-2">{value}</span>}
        {!destructive && <ChevronRight className="h-4 w-4 text-muted-foreground" />}
      </div>
    </motion.div>
  );
};

const Settings = () => {
  const navigate = useNavigate();
  const { logoutUser, currentUser } = useWallet();
  
  return (
    <div className="min-h-screen pb-24 bg-background text-foreground">
      <header className="p-4">
        <div className="flex items-center">
          <Button 
            variant="ghost" 
            size="icon" 
            className="mr-2"
            onClick={() => navigate('/')}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-semibold">Pengaturan</h1>
        </div>
      </header>
      
      <main className="px-2">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {currentUser && (
             <SettingSection title={`Akun: ${currentUser.email}`}>
                <Dialog>
                  <DialogTrigger asChild>
                     <SettingItem icon={LogOut} title="Keluar" destructive />
                  </DialogTrigger>
                  <DialogContent className="bg-neutral-800 border-neutral-700">
                    <DialogHeader>
                      <DialogTitle>Keluar Akun?</DialogTitle>
                      <DialogDescription>
                        Apakah Anda yakin ingin keluar dari akun Anda? Anda perlu masuk kembali untuk mengakses dompet Anda.
                      </DialogDescription>
                    </DialogHeader>
                    <DialogFooter>
                      <DialogClose asChild><Button variant="outline" className="border-neutral-600 hover:bg-neutral-700">Batal</Button></DialogClose>
                      <Button variant="destructive" onClick={logoutUser}>Ya, Keluar</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
            </SettingSection>
          )}


          <SettingSection>
            <SettingItem icon={Shield} title="Keamanan" onClick={() => {}} />
            <SettingItem icon={BookKey} title="Buku Alamat" onClick={() => {}} />
            <SettingItem icon={SettingsIcon} title="Pengaturan Node" onClick={() => {}} />
            <SettingItem icon={Network} title="Jaringan Khusus" onClick={() => {}} />
            <SettingItem icon={Trash2} title="Bersihkan Cache" onClick={() => {}} />
          </SettingSection>

          <SettingSection>
            <SettingItem icon={Palette} title="Tampilan" value="Mode Gelap" onClick={() => {}} />
            <SettingItem icon={TrendingUp} title="Biaya Transaksi" value="Tengah" onClick={() => {}} />
            <SettingItem icon={Languages} title="Bahasa" value="Bahasa Indonesia" onClick={() => {}} />
            <SettingItem icon={Sun} title="Fiat Currency" value="$ USD" onClick={() => {}} />
          </SettingSection>
          
          <SettingSection>
            <SettingItem icon={LifeBuoy} title="Pusat Bantuan" onClick={() => {}} />
            <SettingItem icon={Users} title="Dukungan" onClick={() => {}} />
            <SettingItem icon={FileText} title="Ketentuan Pengguna" onClick={() => {}} />
          </SettingSection>
          
          <div className="mt-6 text-center">
            <p className="text-muted-foreground text-xs">Versi Aplikasi 1.0.0</p>
          </div>
        </motion.div>
      </main>
      
      <Navigation />
    </div>
  );
};

export default Settings;