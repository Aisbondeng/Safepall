import React from 'react';
import { motion } from 'framer-motion';
import { Eye, EyeOff, Bell, Scan, ChevronDown, Plus, Send, Download, MoreHorizontal, Search, Briefcase, ShoppingCart, Zap, BarChart3 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import Navigation from '@/components/layout/Navigation';
import TransactionItem from '@/components/wallet/TransactionItem';
import { useWallet } from '@/contexts/WalletContext';
import { useNavigate } from 'react-router-dom';

const Dashboard = () => {
  const navigate = useNavigate();
  const { balance, transactions, addTestBitcoin, walletName } = useWallet();
  const [balanceVisible, setBalanceVisible] = React.useState(true);
  const btcPrice = 65432.10;
  const usdValue = balance * btcPrice;

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const actionButtons = [
    { label: "Kirim", icon: Send, path: "/send" },
    { label: "Terima", icon: Download, path: "/receive" },
    { label: "Beli", icon: ShoppingCart, path: "/buy" },
    { label: "Tukar", icon: MoreHorizontal, path: "/swap" },
  ];

  const featureCards = [
    { title: "Earn", description: "Dapatkan bunga dari aset Anda", icon: Zap, path: "/earn", color: "bg-blue-500/20", textColor: "text-blue-400" },
    { title: "NFT", description: "Jelajahi koleksi digital unik", icon: Briefcase, path: "/nft", color: "bg-purple-500/20", textColor: "text-purple-400" },
    { title: "DeFi", description: "Akses layanan keuangan terdesentralisasi", icon: BarChart3, path: "/dapps?category=defi", color: "bg-green-500/20", textColor: "text-green-400" },
  ];

  return (
    <div className="min-h-screen pb-24 bg-background text-foreground">
      <header className="p-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <Button variant="ghost" size="icon" className="mr-2">
              <Scan className="h-5 w-5" />
            </Button>
            <Button variant="ghost" className="p-0 h-auto" onClick={() => navigate('/wallet-management')}>
              <div className="flex items-center">
                <span className="font-semibold">{walletName}</span>
                <ChevronDown className="h-4 w-4 ml-1 text-muted-foreground" />
              </div>
            </Button>
          </div>
          <div className="flex items-center">
            <Button variant="ghost" size="icon" className="mr-1" onClick={() => navigate('/notifications')}>
              <Bell className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" onClick={addTestBitcoin}>
              <Plus className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>
      
      <main className="px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="bg-neutral-800 p-4 rounded-lg shadow-md mb-6"
        >
          <div className="flex justify-between items-center mb-1">
            <span className="text-xs text-muted-foreground">Total Saldo</span>
            <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setBalanceVisible(!balanceVisible)}>
              {balanceVisible ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </Button>
          </div>
          {balanceVisible ? (
            <>
              <div className="text-3xl font-bold">${usdValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
              <div className="text-sm text-muted-foreground">{balance.toFixed(8)} BTC</div>
            </>
          ) : (
            <div className="text-3xl font-bold">********</div>
          )}
        </motion.div>

        <div className="grid grid-cols-4 gap-2 mb-6">
          {actionButtons.map(action => (
            <Button 
              key={action.label} 
              variant="secondary" 
              className="flex flex-col items-center h-auto py-3 bg-neutral-800 hover:bg-neutral-700 text-xs"
              onClick={() => action.path && navigate(action.path)}
            >
              <action.icon className="h-5 w-5 mb-1" />
              <span>{action.label}</span>
            </Button>
          ))}
        </div>

        <div className="grid grid-cols-3 gap-3 mb-6">
          {featureCards.map(feature => (
            <motion.div
              key={feature.title}
              whileHover={{ scale: 1.05 }}
              onClick={() => navigate(feature.path)}
              className={`p-3 rounded-lg ${feature.color} cursor-pointer`}
            >
              <feature.icon className={`h-6 w-6 mb-1 ${feature.textColor}`} />
              <h3 className={`text-sm font-semibold ${feature.textColor}`}>{feature.title}</h3>
              <p className="text-xs text-muted-foreground">{feature.description}</p>
            </motion.div>
          ))}
        </div>


        <Tabs defaultValue="coin" className="mt-6">
          <TabsList className="grid w-full grid-cols-4 bg-neutral-800 mb-4">
            <TabsTrigger value="coin" className="data-[state=active]:bg-neutral-700 data-[state=active]:text-primary">Koin</TabsTrigger>
            <TabsTrigger value="nft" className="data-[state=active]:bg-neutral-700 data-[state=active]:text-primary">NFT</TabsTrigger>
            <TabsTrigger value="defi" className="data-[state=active]:bg-neutral-700 data-[state=active]:text-primary">DeFi</TabsTrigger>
            <TabsTrigger value="history" className="data-[state=active]:bg-neutral-700 data-[state=active]:text-primary" onClick={() => navigate('/history')}>Riwayat</TabsTrigger>
          </TabsList>
          
          <TabsContent value="coin">
            <div className="relative mb-4">
              <Input 
                type="text" 
                placeholder="Cari Koin" 
                className="bg-neutral-800 border-neutral-700 pl-10"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            </div>

            <motion.div
              variants={container}
              initial="hidden"
              animate="show"
              className="space-y-2"
            >
              <Card className="bg-neutral-800 border-neutral-700 rounded-lg">
                <CardContent className="p-3 flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-8 h-8 rounded-full bitcoin-gradient flex items-center justify-center mr-3">
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" className="h-5 w-5 text-white fill-current"><path d="M29.333 16c0-2.385-.794-4.632-2.207-6.455l-2.406-3.145-1.538.087c-2.06-.46-4.24-.704-6.515-.704s-4.455.244-6.515.704l-1.538-.087L6.207 9.545C4.794 11.368 4 13.615 4 16s.794 4.632 2.207 6.455l2.406 3.145 1.538-.087c2.06.46 4.24.704 6.515.704s4.455-.244 6.515-.704l1.538.087 2.406-3.145C28.539 20.632 29.333 18.385 29.333 16zM14.61 21.154v2.32c0 .238-.192.43-.43.43h-1.59c-.238 0-.43-.192-.43-.43v-2.32H10.4v-1.473h1.76v-1.486h-1.76v-1.473h1.76V15.2H10.4v-1.473h1.76v-2.32c0-.238.192-.43.43-.43h1.59c.238 0 .43.192.43.43v2.32h1.76v1.473h-1.76v1.486h1.76v1.473h-1.76v1.535h1.76v1.473h-1.76zm7.056-1.473H19.9v2.32c0 .238-.192.43-.43.43h-1.59c-.238 0-.43-.192-.43-.43v-2.32H15.7v-1.473h1.76v-4.64c0-.238.192-.43.43-.43h1.59c.238 0 .43.192.43.43v4.64h1.756v1.473z"></path></svg>
                    </div>
                    <div>
                      <h3 className="font-medium">BTC <span className="text-xs text-muted-foreground">Bitcoin</span></h3>
                      <p className="text-xs text-muted-foreground">${btcPrice.toLocaleString()}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">{balance.toFixed(4)}</p>
                    <p className="text-xs text-muted-foreground">${usdValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                  </div>
                </CardContent>
              </Card>
              
              {transactions.length > 0 ? (
                transactions.slice(0, 2).map(transaction => (
                  <TransactionItem key={transaction.id} transaction={transaction} />
                ))
              ) : (
                <Card className="bg-neutral-800 border-neutral-700 rounded-lg">
                  <CardContent className="p-6 text-center">
                    <p className="text-muted-foreground">Belum ada transaksi</p>
                  </CardContent>
                </Card>
              )}
              {transactions.length > 2 && (
                <Button variant="link" className="w-full text-primary text-xs" onClick={() => navigate('/history')}>Lihat semua transaksi</Button>
              )}
            </motion.div>
          </TabsContent>
          
          <TabsContent value="nft">
            <Card className="bg-neutral-800 border-neutral-700 rounded-lg">
              <CardContent className="p-6 text-center">
                <Briefcase className="h-12 w-12 mx-auto text-muted-foreground mb-2" />
                <p className="text-muted-foreground">Koleksi NFT Anda akan muncul di sini.</p>
                <Button className="mt-4 safepal-gradient-button text-primary-foreground" onClick={() => navigate('/nft')}>Jelajahi NFT</Button>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="defi">
            <Card className="bg-neutral-800 border-neutral-700 rounded-lg">
              <CardContent className="p-6 text-center">
                <BarChart3 className="h-12 w-12 mx-auto text-muted-foreground mb-2" />
                <p className="text-muted-foreground">Aset DeFi Anda akan ditampilkan di sini.</p>
                <Button className="mt-4 safepal-gradient-button text-primary-foreground" onClick={() => navigate('/dapps?category=defi')}>Jelajahi DeFi</Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <Card className="mt-6 bg-neutral-800 border-neutral-700 rounded-lg">
          <CardHeader className="p-3 border-b border-neutral-700">
            <CardTitle className="text-sm font-semibold">Berita & Pengumuman</CardTitle>
          </CardHeader>
          <CardContent className="p-3 space-y-2">
            <div className="text-xs text-muted-foreground">
              <span className="font-semibold text-primary">[PENTING]</span> Pembaruan keamanan terjadwal pada 25 Mei 2025.
            </div>
            <div className="text-xs text-muted-foreground">
              <span className="font-semibold text-green-400">[BARU]</span> Fitur Staking ETH telah diluncurkan!
            </div>
          </CardContent>
        </Card>

      </main>
      
      <Navigation />
    </div>
  );
};

export default Dashboard;