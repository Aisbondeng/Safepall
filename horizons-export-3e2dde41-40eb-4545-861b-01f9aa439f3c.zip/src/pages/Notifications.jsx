import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Bell, Trash2, CheckCircle2, AlertTriangle, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';

const initialNotifications = [
  { id: 1, type: 'success', title: 'Transaksi Berhasil', message: '0.05 BTC berhasil dikirim ke bc1q...', time: '5 menit lalu', read: false, icon: <CheckCircle2 className="h-5 w-5 text-green-400" /> },
  { id: 2, type: 'warning', title: 'Peringatan Keamanan', message: 'Login dari perangkat baru terdeteksi.', time: '1 jam lalu', read: false, icon: <AlertTriangle className="h-5 w-5 text-yellow-400" /> },
  { id: 3, type: 'info', title: 'Pembaruan Aplikasi', message: 'Versi 1.0.1 tersedia. Segera perbarui!', time: '3 jam lalu', read: true, icon: <Info className="h-5 w-5 text-blue-400" /> },
  { id: 4, type: 'success', title: 'Bitcoin Diterima', message: 'Anda menerima 0.01 BTC dari TestFaucet.', time: 'Kemarin', read: true, icon: <CheckCircle2 className="h-5 w-5 text-green-400" /> },
];

const Notifications = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [notifications, setNotifications] = useState(initialNotifications);

  const markAsRead = (id) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    toast({ title: "Semua notifikasi ditandai terbaca", className: "bg-neutral-800 text-foreground border-neutral-700" });
  };
  
  const clearAllNotifications = () => {
    setNotifications([]);
    toast({ title: "Semua notifikasi dihapus", className: "bg-neutral-800 text-foreground border-neutral-700" });
  };


  return (
    <div className="min-h-screen pb-16 bg-background text-foreground">
      <header className="p-4 sticky top-0 bg-background z-10 border-b border-neutral-700">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Button 
              variant="ghost" 
              size="icon" 
              className="mr-2"
              onClick={() => navigate('/')}
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-xl font-semibold">Notifikasi</h1>
          </div>
          <div className="flex items-center space-x-1">
            <Button variant="ghost" size="sm" onClick={markAllAsRead} className="text-xs">Tandai Semua Terbaca</Button>
            <Button variant="ghost" size="icon" onClick={clearAllNotifications}><Trash2 className="h-4 w-4 text-red-400" /></Button>
          </div>
        </div>
      </header>

      <main className="px-4 py-4">
        {notifications.length === 0 ? (
          <div className="text-center py-20">
            <Bell className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Tidak ada notifikasi baru.</p>
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ staggerChildren: 0.1 }}
            className="space-y-3"
          >
            {notifications.map(notif => (
              <motion.div
                key={notif.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -20 }}
                onClick={() => markAsRead(notif.id)}
              >
                <Card className={`rounded-lg border-l-4 ${notif.read ? 'bg-neutral-800/70 border-neutral-700' : 'bg-neutral-800 border-primary/50'} cursor-pointer`}>
                  <CardContent className="p-3">
                    <div className="flex items-start">
                      <div className="mr-3 mt-1">{notif.icon}</div>
                      <div className="flex-1">
                        <h3 className={`text-sm font-semibold ${notif.read ? 'text-muted-foreground' : ''}`}>{notif.title}</h3>
                        <p className={`text-xs ${notif.read ? 'text-muted-foreground/70' : 'text-muted-foreground'}`}>{notif.message}</p>
                        <p className="text-xs text-muted-foreground/50 mt-1">{notif.time}</p>
                      </div>
                      {!notif.read && <div className="w-2 h-2 bg-primary rounded-full ml-2 mt-1"></div>}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        )}
      </main>
    </div>
  );
};

export default Notifications;