import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import { WalletProvider, useWallet } from '@/contexts/WalletContext';
import Dashboard from '@/pages/Dashboard';
import Send from '@/pages/Send';
import Receive from '@/pages/Receive';
import History from '@/pages/History';
import Settings from '@/pages/Settings';
import Swap from '@/pages/Swap';
import Dapps from '@/pages/Dapps';
import Market from '@/pages/Market';
import BuyCrypto from '@/pages/BuyCrypto';
import NftMarketplace from '@/pages/NftMarketplace';
import Earn from '@/pages/Earn';
import WalletManagement from '@/pages/WalletManagement';
import Notifications from '@/pages/Notifications';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import Welcome from '@/pages/Welcome';

const ProtectedRoute = ({ children }) => {
  const { isAuthenticated } = useWallet();
  if (!isAuthenticated) {
    return <Navigate to="/welcome" replace />;
  }
  return children;
};

const AuthRoute = ({ children }) => {
  const { isAuthenticated } = useWallet();
  if (isAuthenticated) {
    return <Navigate to="/" replace />;
  }
  return children;
};

function App() {
  return (
    <WalletProvider>
      <AppContent />
    </WalletProvider>
  );
}

function AppContent() {
  const { isAuthenticated, isInitialLoading } = useWallet();

  if (isInitialLoading) {
    return (
      <div className="min-h-screen wallet-bg dark flex items-center justify-center">
        <div className="text-white">Memuat Aplikasi...</div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen wallet-bg dark">
      <Routes>
        <Route path="/welcome" element={<AuthRoute><Welcome /></AuthRoute>} />
        <Route path="/login" element={<AuthRoute><Login /></AuthRoute>} />
        <Route path="/register" element={<AuthRoute><Register /></AuthRoute>} />
        
        <Route path="/" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
        <Route path="/send" element={<ProtectedRoute><Send /></ProtectedRoute>} />
        <Route path="/receive" element={<ProtectedRoute><Receive /></ProtectedRoute>} />
        <Route path="/swap" element={<ProtectedRoute><Swap /></ProtectedRoute>} />
        <Route path="/history" element={<ProtectedRoute><History /></ProtectedRoute>} />
        <Route path="/settings" element={<ProtectedRoute><Settings /></ProtectedRoute>} />
        <Route path="/dapps" element={<ProtectedRoute><Dapps /></ProtectedRoute>} />
        <Route path="/market" element={<ProtectedRoute><Market /></ProtectedRoute>} />
        <Route path="/buy" element={<ProtectedRoute><BuyCrypto /></ProtectedRoute>} />
        <Route path="/nft" element={<ProtectedRoute><NftMarketplace /></ProtectedRoute>} />
        <Route path="/earn" element={<ProtectedRoute><Earn /></ProtectedRoute>} />
        <Route path="/wallet-management" element={<ProtectedRoute><WalletManagement /></ProtectedRoute>} />
        <Route path="/notifications" element={<ProtectedRoute><Notifications /></ProtectedRoute>} />
      </Routes>
      <Toaster />
    </div>
  );
}


export default App;