import React, { createContext, useContext, useState, useEffect } from 'react';
import { useToast } from '@/components/ui/use-toast';

const WalletContext = createContext();

export const useWallet = () => {
  const context = useContext(WalletContext);
  if (!context) {
    throw new Error('useWallet must be used within a WalletProvider');
  }
  return context;
};

export const WalletProvider = ({ children }) => {
  const { toast } = useToast();
  const [balance, setBalance] = useState(0);
  const [transactions, setTransactions] = useState([]);
  const [address, setAddress] = useState('bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh');
  const [loading, setLoading] = useState(false);
  const [walletName, setWalletName] = useState('Wallet01-4GX');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isInitialLoading, setIsInitialLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);


  useEffect(() => {
    const storedAuth = localStorage.getItem('isAuthenticated');
    const storedUser = localStorage.getItem('currentUser');

    if (storedAuth === 'true' && storedUser) {
      setIsAuthenticated(true);
      setCurrentUser(JSON.parse(storedUser));
      const savedBalance = localStorage.getItem(`${JSON.parse(storedUser).email}-btcBalance`);
      const savedTransactions = localStorage.getItem(`${JSON.parse(storedUser).email}-btcTransactions`);
      const savedWalletName = localStorage.getItem(`${JSON.parse(storedUser).email}-btcWalletName`);
      
      if (savedBalance) setBalance(parseFloat(savedBalance));
      if (savedTransactions) setTransactions(JSON.parse(savedTransactions));
      if (savedWalletName) setWalletName(savedWalletName);
      else setWalletName(`Wallet-${JSON.parse(storedUser).email.split('@')[0]}`);

    }
    setIsInitialLoading(false);
  }, []);

  useEffect(() => {
    if (isAuthenticated && currentUser) {
      localStorage.setItem('isAuthenticated', 'true');
      localStorage.setItem('currentUser', JSON.stringify(currentUser));
      localStorage.setItem(`${currentUser.email}-btcBalance`, balance.toString());
      localStorage.setItem(`${currentUser.email}-btcTransactions`, JSON.stringify(transactions));
      localStorage.setItem(`${currentUser.email}-btcWalletName`, walletName);
    } else {
      localStorage.removeItem('isAuthenticated');
      localStorage.removeItem('currentUser');
    }
  }, [isAuthenticated, currentUser, balance, transactions, walletName]);
  
  const loginUser = (email, password) => {
    setLoading(true);
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const storedUsers = JSON.parse(localStorage.getItem('walletUsers') || '[]');
        const user = storedUsers.find(u => u.email === email && u.password === password); // In real app, hash password
        if (user) {
          setIsAuthenticated(true);
          setCurrentUser({ email: user.email });
          
          const savedBalance = localStorage.getItem(`${user.email}-btcBalance`);
          const savedTransactions = localStorage.getItem(`${user.email}-btcTransactions`);
          const savedWalletName = localStorage.getItem(`${user.email}-btcWalletName`);

          setBalance(savedBalance ? parseFloat(savedBalance) : 0);
          setTransactions(savedTransactions ? JSON.parse(savedTransactions) : []);
          setWalletName(savedWalletName || `Wallet-${user.email.split('@')[0]}`);
          setAddress(`bc1q${user.email.substring(0,5)}${Math.random().toString(36).substring(2,15)}`);


          toast({ title: "Login Berhasil", description: `Selamat datang kembali, ${email}!`, className: "bg-neutral-800 text-foreground border-neutral-700" });
          resolve(true);
        } else {
          toast({ variant: "destructive", title: "Login Gagal", description: "Email atau password salah." });
          reject(false);
        }
        setLoading(false);
      }, 1000);
    });
  };

  const registerUser = (email, password) => {
    setLoading(true);
     return new Promise((resolve, reject) => {
        setTimeout(() => {
          let storedUsers = JSON.parse(localStorage.getItem('walletUsers') || '[]');
          if (storedUsers.find(u => u.email === email)) {
            toast({ variant: "destructive", title: "Registrasi Gagal", description: "Email sudah terdaftar." });
            setLoading(false);
            reject(false);
            return;
          }
          storedUsers.push({ email, password }); // In real app, hash password
          localStorage.setItem('walletUsers', JSON.stringify(storedUsers));
          
          toast({ title: "Registrasi Berhasil", description: "Akun Anda telah dibuat. Silakan login.", className: "bg-neutral-800 text-foreground border-neutral-700" });
          setLoading(false);
          resolve(true);
        }, 1000);
    });
  };

  const logoutUser = () => {
    setIsAuthenticated(false);
    setCurrentUser(null);
    setBalance(0);
    setTransactions([]);
    setWalletName('Wallet01-4GX'); 
    setAddress('bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh');
    toast({ title: "Logout Berhasil", description: "Anda telah keluar.", className: "bg-neutral-800 text-foreground border-neutral-700" });
  };


  const sendBitcoin = (recipient, amount, memo = '') => {
    setLoading(true);
    
    setTimeout(() => {
      if (amount <= 0) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Jumlah harus lebih besar dari 0",
        });
        setLoading(false);
        return;
      }
      
      if (amount > balance) {
        toast({
          variant: "destructive",
          title: "Saldo tidak cukup",
          description: "Anda tidak memiliki cukup Bitcoin untuk transaksi ini.",
        });
        setLoading(false);
        return;
      }
      
      const newTransaction = {
        id: Date.now().toString(),
        type: 'send',
        amount: amount,
        recipient: recipient,
        memo: memo,
        timestamp: new Date().toISOString(),
        status: 'completed'
      };
      
      setBalance(prevBalance => prevBalance - amount);
      setTransactions(prev => [newTransaction, ...prev]);
      
      toast({
        title: "Transaksi berhasil",
        description: `${amount} BTC dikirim ke ${recipient.substring(0, 8)}...`,
        className: "bg-neutral-800 text-foreground border-neutral-700"
      });
      
      setLoading(false);
    }, 1500);
  };

  const receiveBitcoin = (amount, sender, memo = '') => {
    setLoading(true);
    
    setTimeout(() => {
      const newTransaction = {
        id: Date.now().toString(),
        type: 'receive',
        amount: amount,
        sender: sender,
        memo: memo,
        timestamp: new Date().toISOString(),
        status: 'completed'
      };
      
      setBalance(prevBalance => prevBalance + amount);
      setTransactions(prev => [newTransaction, ...prev]);
      
      toast({
        title: "Bitcoin diterima",
        description: `${amount} BTC diterima dari ${sender.substring(0, 8)}...`,
        className: "bg-neutral-800 text-foreground border-neutral-700"
      });
      
      setLoading(false);
    }, 1500);
  };

  const addTestBitcoin = () => {
    const amount = Math.random() * 0.1 + 0.01; 
    receiveBitcoin(parseFloat(amount.toFixed(8)), 'TestFaucet', 'Dana uji coba');
  };

  const updateWalletName = (newName) => {
    if (newName && newName.trim() !== "") {
      setWalletName(newName.trim());
      toast({
        title: "Nama Wallet Diperbarui",
        description: `Nama wallet diubah menjadi ${newName.trim()}`,
        className: "bg-neutral-800 text-foreground border-neutral-700"
      });
    } else {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Nama wallet tidak boleh kosong.",
      });
    }
  };


  return (
    <WalletContext.Provider value={{
      balance,
      transactions,
      address,
      loading,
      walletName,
      isAuthenticated,
      isInitialLoading,
      currentUser,
      loginUser,
      registerUser,
      logoutUser,
      sendBitcoin,
      receiveBitcoin,
      addTestBitcoin,
      updateWalletName
    }}>
      {children}
    </WalletContext.Provider>
  );
};