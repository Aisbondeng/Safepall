
import React from 'react';
import { motion } from 'framer-motion';

const QRCode = ({ address, size = 200 }) => {
  // This is a placeholder for a real QR code
  // In a real app, you would use a QR code library
  
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center"
    >
      <div 
        className="bg-white p-4 rounded-lg shadow-lg"
        style={{ width: size, height: size }}
      >
        <div className="w-full h-full border-8 border-black rounded relative overflow-hidden">
          <div className="absolute top-0 left-0 w-16 h-16 border-t-8 border-l-8 border-black"></div>
          <div className="absolute top-0 right-0 w-16 h-16 border-t-8 border-r-8 border-black"></div>
          <div className="absolute bottom-0 left-0 w-16 h-16 border-b-8 border-l-8 border-black"></div>
          <div className="absolute bottom-0 right-0 w-16 h-16 border-b-8 border-r-8 border-black"></div>
          
          <div className="absolute inset-0 grid grid-cols-7 grid-rows-7">
            {Array.from({ length: 49 }).map((_, i) => {
              // Create a pseudo-random pattern based on the address
              const shouldFill = (
                address.charCodeAt(i % address.length) + i
              ) % 3 === 0;
              
              return (
                <div 
                  key={i}
                  className={`${shouldFill ? 'bg-black' : 'bg-white'}`}
                ></div>
              );
            })}
          </div>
          
          <div className="absolute inset-0 m-auto w-16 h-16 bg-white flex items-center justify-center">
            <div className="w-12 h-12 bitcoin-gradient rounded-md"></div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default QRCode;
